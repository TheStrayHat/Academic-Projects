import { useState } from "react";
import { Network, Trash2, Plus, ArrowRight, Play, GitBranch } from "lucide-react";
import { toast } from "sonner";

interface Edge {
  from: string;
  to: string;
  weight: number;
}

export default function App() {
  const [nodes, setNodes] = useState<string>("");
  const [edges, setEdges] = useState<Edge[]>([]);
  const [startNode, setStartNode] = useState<string>("");
  const [endNode, setEndNode] = useState<string>("");
  const [currentEdge, setCurrentEdge] = useState<Edge>({ from: "", to: "", weight: 0 });

  const nodeList = nodes.split(",").map((n) => n.trim()).filter(Boolean);

  const addEdge = () => {
    if (!currentEdge.from || !currentEdge.to) {
      toast.error("Please fill in From and To fields");
      return;
    }
    if (!nodeList.includes(currentEdge.from) || !nodeList.includes(currentEdge.to)) {
      toast.error("Edge nodes must exist in the node list");
      return;
    }
    setEdges([...edges, currentEdge]);
    setCurrentEdge({ from: "", to: "", weight: 0 });
    toast.success("Edge added");
  };

  const removeEdge = (index: number) => {
    setEdges(edges.filter((_, i) => i !== index));
  };

  const clearAll = () => {
    setNodes("");
    setEdges([]);
    setStartNode("");
    setEndNode("");
    setCurrentEdge({ from: "", to: "", weight: 0 });
    toast.success("Cleared");
  };

  const handleCalculate = () => {
    if (!nodes || edges.length === 0 || !startNode || !endNode) {
      toast.error("Please complete all fields before calculating");
      return;
    }
    if (!nodeList.includes(startNode) || !nodeList.includes(endNode)) {
      toast.error("Start and end nodes must exist in the node list");
      return;
    }
    toast.success("Ready to calculate — results panel coming soon");
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Top bar */}
      <header className="border-b border-border bg-card px-8 py-4 flex items-center gap-3 shrink-0">
        <div className="flex items-center justify-center size-9 rounded-lg bg-primary">
          <Network className="size-5 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-base font-semibold tracking-tight leading-none">
            Bellman-Kalaba
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5 font-mono">
            Shortest-path algorithm
          </p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-xs text-muted-foreground font-mono">
            {nodeList.length} nodes · {edges.length} edges
          </span>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 flex items-start justify-center px-6 py-10">
        <div className="w-full max-w-2xl space-y-5">

          {/* Section label */}
          <div className="flex items-center gap-2">
            <GitBranch className="size-4 text-muted-foreground" />
            <span className="text-sm font-semibold tracking-wide uppercase text-muted-foreground">
              Graph Configuration
            </span>
          </div>

          {/* Nodes card */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-border">
              <h2 className="text-sm font-semibold">Nodes</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                Enter node identifiers separated by commas
              </p>
            </div>
            <div className="px-5 py-4 space-y-3">
              <input
                type="text"
                placeholder="e.g.  A, B, C, D, E"
                value={nodes}
                onChange={(e) => setNodes(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-border bg-background font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50 transition"
              />
              {nodeList.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {nodeList.map((node) => (
                    <span
                      key={node}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-md bg-primary/10 text-primary text-xs font-mono font-medium border border-primary/20"
                    >
                      {node}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Edges card */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-border">
              <h2 className="text-sm font-semibold">Edges</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                Define directed edges with their weights
              </p>
            </div>
            <div className="px-5 py-4 space-y-4">
              {/* Add edge row */}
              <div className="grid grid-cols-[1fr,auto,1fr,80px,auto] gap-2 items-end">
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground font-medium">From</label>
                  <input
                    type="text"
                    placeholder="Node"
                    value={currentEdge.from}
                    onChange={(e) =>
                      setCurrentEdge({ ...currentEdge, from: e.target.value.trim().toUpperCase() })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50 transition"
                  />
                </div>

                <div className="pb-2">
                  <ArrowRight className="size-4 text-muted-foreground" />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground font-medium">To</label>
                  <input
                    type="text"
                    placeholder="Node"
                    value={currentEdge.to}
                    onChange={(e) =>
                      setCurrentEdge({ ...currentEdge, to: e.target.value.trim().toUpperCase() })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50 transition"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground font-medium">Weight</label>
                  <input
                    type="number"
                    placeholder="0"
                    value={currentEdge.weight || ""}
                    onChange={(e) =>
                      setCurrentEdge({ ...currentEdge, weight: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50 transition"
                  />
                </div>

                <div className="pb-0.5">
                  <button
                    onClick={addEdge}
                    className="size-9 flex items-center justify-center rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition shrink-0"
                  >
                    <Plus className="size-4" />
                  </button>
                </div>
              </div>

              {/* Edge list */}
              {edges.length > 0 && (
                <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
                  {edges.map((edge, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between px-3 py-2 rounded-lg bg-muted/40 border border-border group"
                    >
                      <div className="flex items-center gap-2 font-mono text-sm">
                        <span className="px-2 py-0.5 rounded bg-background border border-border text-xs font-semibold">
                          {edge.from}
                        </span>
                        <ArrowRight className="size-3.5 text-muted-foreground" />
                        <span className="px-2 py-0.5 rounded bg-background border border-border text-xs font-semibold">
                          {edge.to}
                        </span>
                        <span className="text-muted-foreground text-xs ml-1">·</span>
                        <span className="text-primary text-xs font-semibold">{edge.weight}</span>
                      </div>
                      <button
                        onClick={() => removeEdge(index)}
                        className="opacity-0 group-hover:opacity-100 transition size-7 flex items-center justify-center rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="size-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {edges.length === 0 && (
                <p className="text-xs text-muted-foreground text-center py-3 font-mono">
                  No edges defined yet
                </p>
              )}
            </div>
          </div>

          {/* Path parameters card */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-border">
              <h2 className="text-sm font-semibold">Path Parameters</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                Select start and destination nodes
              </p>
            </div>
            <div className="px-5 py-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground font-medium">Start node</label>
                  <input
                    type="text"
                    placeholder="e.g.  A"
                    value={startNode}
                    onChange={(e) => setStartNode(e.target.value.trim().toUpperCase())}
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50 transition"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground font-medium">End node</label>
                  <input
                    type="text"
                    placeholder="e.g.  E"
                    value={endNode}
                    onChange={(e) => setEndNode(e.target.value.trim().toUpperCase())}
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50 transition"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-1">
                <button
                  onClick={handleCalculate}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition"
                >
                  <Play className="size-4" />
                  Calculate Optimal Path
                </button>
                <button
                  onClick={clearAll}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border bg-background text-sm font-medium text-muted-foreground hover:text-foreground hover:border-foreground/30 transition"
                >
                  <Trash2 className="size-4" />
                  Clear
                </button>
              </div>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}
